# Assignment-1-Cafe-website
 created a page Using table tag 
